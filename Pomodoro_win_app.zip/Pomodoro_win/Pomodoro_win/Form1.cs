﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pomodoro_win
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Text = "Czas do końca nauki: ";
            label2.Text = "25 m";
        }
        int czas = 0;
        bool przerwa = false;
        System.Media.SoundPlayer player = new System.Media.SoundPlayer($@"{AppDomain.CurrentDomain.BaseDirectory }\First_end_work.wav");
        private void timer1_Tick(object sender, EventArgs e)
        {
      
            czas++;
            int time = 1500;
            int time_p = 300;
            if (!przerwa)
            {
                label2.Text = Math.Floor((double)(time - czas) / 60) + " m " + (60 - (czas % 60)) + " s";
                if (czas == time)
                {
                    player.Play();
                    czas = 0;
                    przerwa = !przerwa;
                    label1.Text = "Czas do końca przerwy: ";
                }

            }
            else
            {
                label2.Text = Math.Floor((double)(time_p - czas) / 60) + " m " + (60 - (czas % 60)) + " s";
                if (czas == time_p)
                {
                    player.Play();
                    czas = 0;
                    przerwa = !przerwa;
                    label1.Text = "Czas do końca nauki: ";
                }
            }
           
        }
    }
}
